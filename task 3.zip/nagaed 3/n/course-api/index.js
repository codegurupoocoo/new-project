const express = require('express');
const app = express();
app.use(express.json()); // To parse JSON bodies

let courses = []; // In-memory list of courses

// Get all courses
app.get('/courses', (req, res) => {
    res.json(courses);
});

// Add a course
app.post('/courses', (req, res) => {
    const { title, description, duration } = req.body;
    const course = {
        id: courses.length + 1,
        title,
        description,
        duration
    };
    courses.push(course);
    res.status(201).json(course);
});

// Update a course by ID
app.put('/courses/:id', (req, res) => {
    const courseId = parseInt(req.params.id);
    const { title, description, duration } = req.body;
    const course = courses.find(c => c.id === courseId);
    if (!course) {
        return res.status(404).json({ message: 'Course not found' });
    }
    course.title = title || course.title;
    course.description = description || course.description;
    course.duration = duration || course.duration;
    res.json(course);
});

// Delete a course by ID
app.delete('/courses/:id', (req, res) => {
    const courseId = parseInt(req.params.id);
    const courseIndex = courses.findIndex(c => c.id === courseId);
    if (courseIndex === -1) {
        return res.status(404).json({ message: 'Course not found' });
    }
    courses.splice(courseIndex, 1);
    res.status(204).send();
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
