const data=[
    
    {name:'tushar', email: 'tushar@gmail.com'},
    {name:'anil', email: 'anil@gmail.com'},
    {name:'ji', email: 'ji@gmail.com' , contact:99999999999},



]
module.exports=data;